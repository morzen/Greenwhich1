from tkinter import *


window = Tk()
window.title("COMP1753 GUI")

window.mainloop()
