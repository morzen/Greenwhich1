from tkinter import *


window = Tk()
window.title("COMP1753 GUI")

lbl = Label(window, text="Hello")
lbl.grid(column=0, row=0)

window.mainloop()
