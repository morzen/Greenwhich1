print("This is my first program")
