from turtle import *


speed(1)
pensize(10)
pencolor("orange")
fillcolor("green")
begin_fill()
forward(100)
left(60)
forward(100)
left(60)
forward(100)
left(60)
forward(100)
left(60)
forward(100)
left(60)
forward(100)
left(60)
end_fill()

exitonclick()
