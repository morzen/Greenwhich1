from turtle import *


forward(200)
left(90)
forward(100)
left(90)
forward(200)
left(90)
forward(100)
left(90)

exitonclick()
