from turtle import *


forward(100)
left(120)
forward(100)
left(120)
forward(100)
left(120)

exitonclick()
