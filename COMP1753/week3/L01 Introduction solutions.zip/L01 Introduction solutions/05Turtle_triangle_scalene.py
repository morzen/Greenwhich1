from turtle import *


# put any numbers you like for the forward()
#  and left() commands (but not left(0))
forward(180)
left(75)
forward(93)
goto(0, 0)

exitonclick()
