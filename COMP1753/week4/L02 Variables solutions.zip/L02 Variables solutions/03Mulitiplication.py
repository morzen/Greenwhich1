number1_str = input(" First number: ")
number2_str = input("Second number: ")
number1 = int(number1_str)
number2 = int(number2_str)
combination = number1 * number2
combination_str = str(combination)
print("Answer: " + combination_str)

print()
input("Press return to continue ...")
