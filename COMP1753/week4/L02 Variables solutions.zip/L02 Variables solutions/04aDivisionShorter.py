number1_str = input(" First number: ")
number2_str = input("Second number: ")
combination = int(number1_str) / int(number2_str)
combination_str = str(combination)
print("Answer: " + combination_str)

print()
input("Press return to continue ...")
