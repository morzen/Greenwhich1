print("Answer: " + str(int(input(" First number: ")) / int(input("Second number: "))))

print()
input("Press return to continue ...")
