from random import randint


name = input("What is your name? ")
minimum = 1
maximum = 100
lucky_number = randint(minimum, maximum)
print("Hello " + name + ", your lucky number is " + str(lucky_number))

print()
input("Press return to continue ...")
