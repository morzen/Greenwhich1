# this solution is OK but involves duplication

name = input("What is your name? ")
if name == "Chris Walshaw":
    print("Hello Chris Walshaw, COMP1753 module leader")
else:
    print("Hello " + name)

print()
input("Press return to continue ...")
