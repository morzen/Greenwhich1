# this solution is better (no duplication)
# but the variable "name" is misleading

name = input("What is your name? ")
if name == "Chris Walshaw":
    name += ", COMP1753 module leader"
print("Hello " + name)

print()
input("Press return to continue ...")
