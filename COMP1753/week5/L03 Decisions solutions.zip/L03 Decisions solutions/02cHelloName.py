# this solution is better still
# (no duplication, meaningful variable names)

name = input("What is your name? ")
message = "Hello " + name
if name == "Chris Walshaw":
    message += ", COMP1753 module leader"
print(message)

print()
input("Press return to continue ...")
