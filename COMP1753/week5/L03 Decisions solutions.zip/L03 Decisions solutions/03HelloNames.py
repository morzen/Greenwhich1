first_name = input("What is your first name? ")
last_name = input("What is your last name? ")
message = "Hello " + first_name + " " + last_name
if first_name == "Chris" and last_name == "Walshaw":
    message += ", COMP1753 module leader"
print(message)

print()
input("Press return to continue ...")
