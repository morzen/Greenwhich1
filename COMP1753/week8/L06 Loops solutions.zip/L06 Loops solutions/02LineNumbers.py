n_lines = int(input("How many lines? "))
counter = 1
while counter <= n_lines:
    print("This is line " + str(counter))
    counter += 1

print()
input("Press return to continue ...")
