for i in range(3):
    print(i)
print()

for i in range(4):
    print(i)
print()

for i in range(1, 4):
    print(i)
print()

for i in range(0, 4, 2):
    print(i)
print()

for i in range(2, 3):
    print(i)
print()

for i in range(4, 3):
    print(i)
print()

for i in range(4, 4):
    print(i)
print()

for i in range(40, 0, -1):
    print(i)
print()

print()
input("Press return to continue ...")
